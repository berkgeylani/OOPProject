package textsimilarty;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.Random;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;

import database.PaperDAO;
import database.PaperMongo;
import database.PaperPOJO;

public class Main {
	private static final String COLLECTION_NAME = "paper";
	private static final String CSV_FILE_PATH = "/home/francium/Downloads/ACM.csv";

	public static void main(String[] args) throws IOException {
		FileUtility fileUtility = new FileUtility();
		PdfTextExtractor pdfTextExtractor = new PdfTextExtractor();
//		ArrayList<Integer> readCSV = fileUtility.readCSV(CSV_FILE_PATH);
//		for (Integer integer : readCSV) {
//			pdfTextExtractor.getDownloadLink(integer.intValue());
//		}
		PaperDAO paperDAO = new PaperMongo(COLLECTION_NAME);
		File file = new File("/home/francium/Desktop/pdfPapers/idAtached");
		File[] listFiles = file.listFiles();
		String pdfContent=null ;
		Random rn = new Random();
		for (int i = 0; i < 10; i++) {
			File filePath = listFiles[rn.nextInt(listFiles.length)];
			String pdfId = filePath.getName().split("\\.")[0];
			pdfContent = pdfTextExtractor.pdfTextExtractor(filePath);
			String[] searchRow = fileUtility.searchCSV(CSV_FILE_PATH, pdfId);
			//"Id","title","authors","venue","year"  <-- content ekleyip pojoya eklencek
			PaperPOJO paperPOJO = new PaperPOJO(new Integer(searchRow[0]).intValue(), searchRow[1], searchRow[2], searchRow[3], new Integer(searchRow[4]), pdfContent);
			paperDAO.addPaper(paperPOJO);
		}
		
	}
	

	
	
}



/*
 * public static void main(String[] args) throws IOException {
//		ArrayList<Integer> readCSV = readCSV("/home/francium/Downloads/ACM.csv");
//		for (Integer integer : readCSV) {
//			getDownloadLink(integer.intValue());
//		}
		new File("/home/francium/workspace/Dataset-creator/");
	}

	private static void getDownloadLink(int id) throws IOException {
		String url = "http://dl.acm.org/citation.cfm?id="+id;
		Document websiteAsHtmlCurrent = Jsoup.connect(url)
				.userAgent("Opera/9.80 (Macintosh; Intel Mac OS X 10.6.8; U; fr) Presto/2.9.168 Version/11.52")
				.get();
		String urlOfPDf = websiteAsHtmlCurrent.getElementsByClass("medium-text").select("a").attr("href");
		pdfDownload("http://dl.acm.org/"+urlOfPDf);
	}
	
	private static void pdfDownload(String Url) throws IOException {
		try{System.out.println("opening connection");
		URL url = new URL(Url);
        URLConnection hc = url.openConnection();
        hc.setRequestProperty("User-Agent", "Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10.4; en-US; rv:1.9.2.2) Gecko/20100316 Firefox/3.6.2");
        InputStream in = hc.getInputStream();
		FileOutputStream fos = new FileOutputStream(new File("a"+System.currentTimeMillis()+".pdf"));

		System.out.println("reading from resource and writing to file...");
		int length = -1;
		byte[] buffer = new byte[1024];// buffer for portion of data from connection
		while ((length = in.read(buffer)) > -1) {
		    fos.write(buffer, 0, length);
		}
		fos.close();
		in.close();
		System.out.println("File downloaded");}catch (Exception e) {
		}
	}
	
	private static ArrayList<Integer> readCSV(String csvFile) {
	        String line = "";
	        String cvsSplitBy = ",";
	        ArrayList<Integer> paperId = new ArrayList<>();
	        try (BufferedReader br = new BufferedReader(new FileReader(csvFile))) {
	        	int i = 0;
	            while ((line = br.readLine()) != null) {
	            	if(i==0){
	            		i++;
	            		continue;
	            	}
	                // use comma as separator
	                String[] row = line.split(cvsSplitBy);
	                paperId.add(new Integer(row[0]));
	            }
	        } catch (IOException e) {
	            e.printStackTrace();
	        }
	        return paperId;
	}
	private static void pdfTextExtractor(String filePath) throws IOException {
		PDDocument document = PDDocument.load(new File(filePath));
		PDFTextStripper pdfTextStripper = new PDFTextStripper();
		String pdfCOntent = pdfTextStripper.getText(document);
		document.close();
	}*/
