package database;

import java.util.ArrayList;
import java.util.List;

import org.bson.Document;

import com.mongodb.MongoClient;
import com.mongodb.MongoClientOptions;
import com.mongodb.ServerAddress;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.result.DeleteResult;

public class PaperMongo implements PaperDAO {
	private static MongoClient mongoClient_INSTANCE;
	
	private static final String LOCALHOST = "localhost";

	private static  final String MONGO_DB_NAME = "mydb";
	
	private static String collectionName ;
	/**
	 * how to use?
	 * insertOne -> herhangi fonksiyon
	 * getCollection(mongoClient).insertOne
	 * @param client
	 * @return
	 */
	public MongoCollection<Document> getCollection(MongoClient client){
		MongoCollection<Document> collection = client.getDatabase(MONGO_DB_NAME).getCollection(this.collectionName);
		return collection;
	}
	
	public static MongoClient getInstance() {
		if (mongoClient_INSTANCE == null) {
			synchronized (MongoClient.class) {
				if (mongoClient_INSTANCE == null) { // yes double check
					mongoClient_INSTANCE = new MongoClient(new ServerAddress(LOCALHOST));
				}
			}
		}
		return mongoClient_INSTANCE;
	}
	
	public PaperMongo(String collectionName) {
		this.collectionName=collectionName;
	}
	
	private ArrayList<PaperPOJO> findIterableToArrayList(FindIterable<Document> iterable) {
		ArrayList<PaperPOJO> dataAl = new ArrayList<>();
		MongoCursor<Document> cursor = iterable.iterator();
		while (cursor.hasNext()) {
			Document document = cursor.next();
			dataAl.add(new PaperPOJO(document.getInteger("_id"), document.getString("title"), document.getString("author"), document.getString("venue"), document.getInteger("year"), document.getString("content")));
		}
		return dataAl;
	}
	
	@Override
	public void addPaper(PaperPOJO paperPojo) {
		MongoClient mongoClient = getInstance();
		getCollection(mongoClient).insertOne(new Document()
				.append("_id", paperPojo.getId())
				.append("title", paperPojo.getTitle())
				.append("authors", paperPojo.getAuthor())
				.append("venue", paperPojo.getVenue())
				.append("year", paperPojo.getYear())
				.append("content", paperPojo.getContent())
				);
	}
	
	@Override
	public List<PaperPOJO> getAllPapers() {
		MongoClient mongoClient = getInstance();
		ArrayList<PaperPOJO> allPapers = findIterableToArrayList(getCollection(mongoClient).find());
		return allPapers;
	}


//	@Override
//	public void updatePaper(PaperPOJO paperPojo) {
//		
//	}

	@Override
	public void deletePaper(int paperId) {
		MongoClient mongoClient = getInstance();
		Document filter = new Document()
			.append("_Id", paperId);
		DeleteResult deleteResult = getCollection(mongoClient).deleteOne(filter);
	}

	@Override
	public PaperPOJO findPaper(int paperId) {
		MongoClient mongoClient = getInstance();
		Document filter = new Document()
			.append("_Id", paperId);
		ArrayList<PaperPOJO> findIterableToArrayList = findIterableToArrayList(getCollection(mongoClient).find(filter));
		return findIterableToArrayList.get(0);
	}

	

}
