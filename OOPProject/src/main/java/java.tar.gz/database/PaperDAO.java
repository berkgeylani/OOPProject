package database;

import java.util.List;

public interface PaperDAO {
	public List<PaperPOJO> getAllPapers();
	public void addPaper(PaperPOJO paperPojo);
//	public void updatePaper(PaperPOJO paperPojo);
	public void deletePaper(int paperId);
	public PaperPOJO findPaper(int id);
}
